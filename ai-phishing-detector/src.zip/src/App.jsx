import Background from "./components/Background";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import EmailInput from "./components/EmailInput";
import ResultCard from "./components/ResultCard";
import Footer from "./components/Footer";
import ThemeToggle from "./components/ThemeToggle";
import { useState } from "react";
import "./App.css";

function App() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  
  const [result, setResult] = useState(null);
  const [dashboardStats, setDashboardStats] = useState({
    safeCount: 0,
    suspiciousCount: 0,
    phishingCount: 0,
    totalScanned: 0,
    avgRiskScore: 0,
    runningRiskSum: 0
  });

  async function analyzeEmail() {
    if (!email.trim()) {
      alert("Please paste an email payload content to invoke cyber scanning engine.");
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      // FIX HERE: Absolute pure string with no hidden markdown attributes
      const response = await fetch("http://127.0.0.1:5000/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: email }),
      });

      const data = await response.json();
      setResult(data);

      setDashboardStats(prev => {
        const newTotal = prev.totalScanned + 1;
        let s = prev.safeCount, susp = prev.suspiciousCount, phish = prev.phishingCount;
        
        if (data.prediction === "Safe") s += 1;
        else if (data.prediction === "Suspicious") susp += 1;
        else if (data.prediction === "Phishing") phish += 1;

        const currentRiskSum = prev.runningRiskSum + data.risk_score;
        return {
          totalScanned: newTotal,
          safeCount: s,
          suspiciousCount: susp,
          phishingCount: phish,
          runningRiskSum: currentRiskSum,
          avgRiskScore: Math.round(currentRiskSum / newTotal)
        };
      });

    } catch (err) {
      console.error("Critical Network Error:", err);
      alert("Backend analysis connection failed.");
    }
    setLoading(false);
  }

  return (
    <div className={darkMode ? "app dark" : "app light"}>
      <Background/>
      <Navbar/>
      <ThemeToggle darkMode={darkMode} setDarkMode={setDarkMode} />
      
      <div className="dashboard-stats-container container-fluid asset-grid">
        <div className="stat-card column-5">
          <h4>Total Ingested Scan Routines</h4>
          <p className="metric-text">{dashboardStats.totalScanned}</p>
        </div>
        <div className="stat-card column-5 safe-theme">
          <h4>Clean Assets</h4>
          <p className="metric-text">{dashboardStats.safeCount}</p>
        </div>
        <div className="stat-card column-5 warning-theme">
          <h4>Suspicious Items</h4>
          <p className="metric-text">{dashboardStats.suspiciousCount}</p>
        </div>
        <div className="stat-card column-5 threat-theme">
          <h4>Phishing Intercepts</h4>
          <p className="metric-text">{dashboardStats.phishingCount}</p>
        </div>
        <div className="stat-card column-5">
          <h4>Systemic Avg Risk Index</h4>
          <p className="metric-text">{dashboardStats.avgRiskScore}%</p>
        </div>
      </div>

      <Hero darkMode={darkMode} />
      
      <div className="main-content">
        <EmailInput
          email={email}
          setEmail={setEmail}
          analyzeEmail={analyzeEmail}
          loading={loading}
          darkMode={darkMode}
        />
        
        {result && (
          <ResultCard 
            result={result} 
            darkMode={darkMode} 
          />
        )}
      </div>
      <Footer/>
    </div>
  );
}

export default App;