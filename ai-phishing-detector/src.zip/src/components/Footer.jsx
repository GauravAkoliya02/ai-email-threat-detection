import { FaGithub, FaLinkedin, FaShieldAlt } from "react-icons/fa";
import { motion } from "framer-motion";

function Footer() {
  return (
    <motion.footer
      className="footer"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <div className="footer-left">
        <FaShieldAlt />
        <span>AI Email Threat Detection System</span>
      </div>

      <div className="footer-center">
        <p>
          © 2026 | Final Year Cyber Security Project | React • Flask • AI
        </p>
      </div>

      <div className="footer-right">
        <FaGithub />
        <FaLinkedin />
      </div>
    </motion.footer>
  );
}

export default Footer;