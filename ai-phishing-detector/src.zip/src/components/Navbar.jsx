import { FaShieldAlt } from "react-icons/fa";

function Navbar() {
  return (
    <nav className="navbar">
      <div className="logo">
        <FaShieldAlt size={28} />
        <span>AI Email Threat Detection</span>
      </div>

      <div className="nav-links">
        <a href="#">Dashboard</a>
        <a href="#">Reports</a>
        <a href="#">About</a>
      </div>
    </nav>
  );
}

export default Navbar;