import { motion } from "framer-motion";
import {
  FaExclamationTriangle,
  FaLink,
  FaUserShield,
  FaGlobe,
} from "react-icons/fa";

function ThreatIndicators({ prediction, darkMode }) {
  const phishing = prediction === "Phishing";

  const indicators = [
    {
      icon: <FaExclamationTriangle />,
      title: "Urgent Language",
      status: phishing ? "Detected" : "Not Found",
    },
    {
      icon: <FaLink />,
      title: "Suspicious Links",
      status: phishing ? "Detected" : "Not Found",
    },
    {
      icon: <FaUserShield />,
      title: "Credential Request",
      status: phishing ? "Detected" : "Not Found",
    },
    {
      icon: <FaGlobe />,
      title: "Unknown Domain",
      status: phishing ? "Detected" : "Trusted",
    },
  ];

  return (
    <motion.div
      className="threat-container"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
    >
      <h2
  style={{
    color: darkMode ? "#FFFFFF" : "#111827",
  }}
>
  Threat Indicators
</h2>

      <div className="indicator-grid">
        {indicators.map((item, index) => (
          <div className="indicator-card" key={index}>
            <div className="indicator-icon">
              {item.icon}
            </div>

            <h3 style={{ color: "#FFFFFF" }}>
  {item.title}
</h3>

            <span
              className={
                phishing
                  ? "indicator-danger"
                  : "indicator-safe"
              }
            >
              {item.status}
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export default ThreatIndicators;