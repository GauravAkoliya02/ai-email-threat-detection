import { motion } from "framer-motion";

function EmailInput({
  email,
  setEmail,
  analyzeEmail,
  loading,
  darkMode,
}) {
  return (
    <motion.section
      className="email-section"
      initial={{ opacity: 0, y: 70 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
    >
      <div className="email-box">

        <h2
  style={{
    color: document.body.classList.contains("light-theme")
      ? "#111827"
      : "#ffffff",
  }}
>
  Analyze Suspicious Email
</h2>

        <p
  style={{
    color: darkMode ? "#cbd5e1" : "#64748b",
    lineHeight: "1.8"
  }}
>
  Paste complete email content below. Our AI engine will analyse phishing indicators,
  malicious intent and social engineering patterns.
</p>

        <textarea
          rows={14}
          placeholder="Paste complete email here..."
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <button
          className="analyze-btn"
          onClick={analyzeEmail}
          disabled={loading}
        >
          {loading ? (
            <>
  <span className="loader"></span>
  🤖 AI Analyzing...
</>
          ) : (
            "Analyze Email"
          )}
        </button>

      </div>
    </motion.section>
  );
}

export default EmailInput;