import RiskMeter from "./RiskMeter";
import ThreatIndicators from "./ThreatIndicators";
import Recommendation from "./Recommendations";
import { motion } from "framer-motion";

function ResultCard({ result, darkMode }) {
  if (!result || !result.prediction) {
    return (
      <div className="result-card empty-card">
        <h2 style={{ color: darkMode ? "#FFFFFF" : "#111827" }}>
          AI Threat Report
        </h2>
        <p style={{ color: darkMode ? "#cbd5e1" : "#64748b" }}>
          Run an analysis to view AI insights.
        </p>
      </div>
    );
  }

  const {
    prediction,
    confidence,
    risk_score,
    explanation,
    summary_card,
    header_analysis,
    url_scanned_details,
    statistics,
    recommendations
  } = result;

  const isSafe = prediction === "Safe";
  const isSuspicious = prediction === "Suspicious";
  const statusColor = isSafe ? "#22c55e" : isSuspicious ? "#f59e0b" : "#ef4444";

  return (
    <motion.div
      className="result-card"
      initial={{ opacity: 0, x: 80 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.7 }}
    >
      <div className="report-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px" }}>
        <h2 style={{ color: "#FFFFFF", margin: 0 }}>
          Threat Intelligence Report
        </h2>
      </div>

      style={{
  borderLeft: 4px solid ${statusColor},
  marginBottom: "20px",
}}
        <h3 style={{ color: "#FFFFFF", fontSize: "1.1rem", marginBottom: "8px" }}>📊 Executive Summary</h3>
        <p style={{ margin: "4px 0" }}><strong>Overall Risk:</strong> <span style={{ color: statusColor, fontWeight: "bold" }}>{summary_card?.overall_risk || "N/A"}</span></p>
        <p style={{ margin: "4px 0" }}><strong>Primary Trigger:</strong> {summary_card?.reason || "Analyzing components..."}</p>
        <p style={{ margin: "4px 0" }}><strong>Required Action:</strong> <span style={{ color: "#fca5a5" }}>{summary_card?.action_required || "None"}</span></p>
      </div>

      <RiskMeter
        prediction={prediction}
        confidence={confidence}
        risk_score={risk_score}
        darkMode={darkMode}
      />

      {/* FIXED HERE: Strict template literals backticks formatting for dynamically generated classes */}
      <div className="info-box authentication-box" style={{ marginBottom: "20px" }}>
        <h3 style={{ color: "#FFFFFF", fontSize: "1.1rem" }}>🔐 Email Authentication (Headers)</h3>
        <div style={{ display: "flex", gap: "10px", margin: "10px 0" }}>
          <span className={badge ${header_analysis?.spf === "PASS" ? "pass-class" : "fail-class"}} style={{ padding: "4px 8px", borderRadius: "4px", fontSize: "0.85rem", background: header_analysis?.spf === "PASS" ? "#14532d" : "#7f1d1d", color: "#fff" }}>
            SPF: {header_analysis?.spf || "NONE"}
          </span>
          <span className={badge ${header_analysis?.dkim === "PASS" ? "pass-class" : "fail-class"}} style={{ padding: "4px 8px", borderRadius: "4px", fontSize: "0.85rem", background: header_analysis?.dkim === "PASS" ? "#14532d" : "#7f1d1d", color: "#fff" }}>
            DKIM: {header_analysis?.dkim || "NONE"}
          </span>
          <span className={badge ${header_analysis?.dmarc === "PASS" ? "pass-class" : "fail-class"}} style={{ padding: "4px 8px", borderRadius: "4px", fontSize: "0.85rem", background: header_analysis?.dmarc === "PASS" ? "#14532d" : "#7f1d1d", color: "#fff" }}>
            DMARC: {header_analysis?.dmarc || "NONE"}
          </span>
        </div>
        <p style={{ fontSize: "0.9rem", margin: 0 }}>Sender Authenticity: <strong>{header_analysis?.authenticity || "Unverified"}</strong></p>
      </div>

      {statistics?.urls > 0 && (
        <div className="info-box url-audit-box" style={{ marginBottom: "20px" }}>
          <h3 style={{ color: "#FFFFFF", fontSize: "1.1rem" }}>🔗 Network URL Security Audit</h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px", marginTop: "10px", textAlign: "center", fontSize: "0.9rem" }}>
            <div style={{ background: "#1e293b", padding: "8px", borderRadius: "6px" }}>
              <div style={{ color: "#22c55e", fontWeight: "bold" }}>{url_scanned_details?.safe_urls?.length || 0}</div>
              <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Safe</span>
            </div>
            <div style={{ background: "#1e293b", padding: "8px", borderRadius: "6px" }}>
              <div style={{ color: "#ef4444", fontWeight: "bold" }}>{url_scanned_details?.suspicious_urls?.length || 0}</div>
              <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Suspicious</span>
            </div>
            <div style={{ background: "#1e293b", padding: "8px", borderRadius: "6px" }}>
              <div style={{ color: "#f59e0b", fontWeight: "bold" }}>{url_scanned_details?.shortened_urls?.length || 0}</div>
              <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>Shortened</span>
            </div>
            <div style={{ background: "#1e293b", padding: "8px", borderRadius: "6px" }}>
              <div style={{ color: "#ec4899", fontWeight: "bold" }}>{url_scanned_details?.ip_urls?.length || 0}</div>
              <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>IP-Based</span>
            </div>
          </div>
        </div>
      )}

      <div className="info-box" style={{ marginBottom: "20px" }}>
        <h3 style={{ color: "#FFFFFF" }}>📝 Security Vulnerability Assessment</h3>
        <p style={{ lineHeight: "1.5", fontSize: "0.95rem" }}>{explanation}</p>
      </div>

      <ThreatIndicators
        prediction={prediction}
        darkMode={darkMode}
        indicators={result.threat_indicators_panel}
      />

      <Recommendation
        prediction={prediction}
        recommendationsList={recommendations}
      />
    </motion.div>
  );
}

export default ResultCard;